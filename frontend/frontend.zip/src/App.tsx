export default function App() {
    return (
        <div className="bg-purple-500 text-white text-xl p-6">
            ✅ Tailwind is working!
        </div>
    );
}